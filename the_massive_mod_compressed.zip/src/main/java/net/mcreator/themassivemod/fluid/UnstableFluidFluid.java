
package net.mcreator.themassivemod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.themassivemod.init.TheMassiveModModItems;
import net.mcreator.themassivemod.init.TheMassiveModModFluids;
import net.mcreator.themassivemod.init.TheMassiveModModBlocks;

public abstract class UnstableFluidFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(TheMassiveModModFluids.UNSTABLE_FLUID,
			TheMassiveModModFluids.FLOWING_UNSTABLE_FLUID,
			FluidAttributes
					.builder(new ResourceLocation("the_massive_mod:blocks/unstablefluid"),
							new ResourceLocation("the_massive_mod:blocks/unstablefluid"))

					.viscosity(2000).temperature(900)

	).explosionResistance(100f).canMultiply().tickRate(3)

			.bucket(TheMassiveModModItems.UNSTABLE_FLUID_BUCKET).block(() -> (LiquidBlock) TheMassiveModModBlocks.UNSTABLE_FLUID.get());

	private UnstableFluidFluid() {
		super(PROPERTIES);
	}

	public static class Source extends UnstableFluidFluid {
		public Source() {
			super();
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends UnstableFluidFluid {
		public Flowing() {
			super();
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
