
package net.mcreator.themassivemod.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.themassivemod.init.TheMassiveModModFluids;

public class UnstableFluidBlock extends LiquidBlock {
	public UnstableFluidBlock() {
		super(() -> (FlowingFluid) TheMassiveModModFluids.UNSTABLE_FLUID.get(), BlockBehaviour.Properties.of(Material.WATER).strength(100f)

				.lightLevel(s -> 15));
	}
}
