
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.themassivemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.themassivemod.block.UnstablePlanePortalBlock;
import net.mcreator.themassivemod.block.UnstableFluidBlock;
import net.mcreator.themassivemod.block.UnactivatedLightiumOreBlock;
import net.mcreator.themassivemod.block.ActivatedLightiumBlockBlock;
import net.mcreator.themassivemod.TheMassiveModMod;

public class TheMassiveModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TheMassiveModMod.MODID);
	public static final RegistryObject<Block> UNACTIVATED_LIGHTIUM_ORE = REGISTRY.register("unactivated_lightium_ore",
			() -> new UnactivatedLightiumOreBlock());
	public static final RegistryObject<Block> ACTIVATED_LIGHTIUM_BLOCK = REGISTRY.register("activated_lightium_block",
			() -> new ActivatedLightiumBlockBlock());
	public static final RegistryObject<Block> UNSTABLE_FLUID = REGISTRY.register("unstable_fluid", () -> new UnstableFluidBlock());
	public static final RegistryObject<Block> UNSTABLE_PLANE_PORTAL = REGISTRY.register("unstable_plane_portal",
			() -> new UnstablePlanePortalBlock());
}
