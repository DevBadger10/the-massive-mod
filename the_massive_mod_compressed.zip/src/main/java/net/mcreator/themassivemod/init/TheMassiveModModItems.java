
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.themassivemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.themassivemod.item.UnstablePlaneItem;
import net.mcreator.themassivemod.item.UnstableFluidItem;
import net.mcreator.themassivemod.item.UnactivatedLightiumDustItem;
import net.mcreator.themassivemod.item.ActivatedLightiumIngotItem;
import net.mcreator.themassivemod.item.ActivatedArmorItem;
import net.mcreator.themassivemod.TheMassiveModMod;

public class TheMassiveModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TheMassiveModMod.MODID);
	public static final RegistryObject<Item> UNACTIVATED_LIGHTIUM_ORE = block(TheMassiveModModBlocks.UNACTIVATED_LIGHTIUM_ORE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> UNACTIVATED_LIGHTIUM_DUST = REGISTRY.register("unactivated_lightium_dust",
			() -> new UnactivatedLightiumDustItem());
	public static final RegistryObject<Item> ACTIVATED_LIGHTIUM_INGOT = REGISTRY.register("activated_lightium_ingot",
			() -> new ActivatedLightiumIngotItem());
	public static final RegistryObject<Item> ACTIVATED_ARMOR_HELMET = REGISTRY.register("activated_armor_helmet",
			() -> new ActivatedArmorItem.Helmet());
	public static final RegistryObject<Item> ACTIVATED_ARMOR_CHESTPLATE = REGISTRY.register("activated_armor_chestplate",
			() -> new ActivatedArmorItem.Chestplate());
	public static final RegistryObject<Item> ACTIVATED_ARMOR_LEGGINGS = REGISTRY.register("activated_armor_leggings",
			() -> new ActivatedArmorItem.Leggings());
	public static final RegistryObject<Item> ACTIVATED_ARMOR_BOOTS = REGISTRY.register("activated_armor_boots", () -> new ActivatedArmorItem.Boots());
	public static final RegistryObject<Item> ACTIVATED_LIGHTIUM_BLOCK = block(TheMassiveModModBlocks.ACTIVATED_LIGHTIUM_BLOCK,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> UNSTABLE_FLUID_BUCKET = REGISTRY.register("unstable_fluid_bucket", () -> new UnstableFluidItem());
	public static final RegistryObject<Item> UNSTABLE_PLANE = REGISTRY.register("unstable_plane", () -> new UnstablePlaneItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
