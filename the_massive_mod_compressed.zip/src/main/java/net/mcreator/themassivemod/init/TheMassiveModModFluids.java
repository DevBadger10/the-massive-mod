
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.themassivemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.themassivemod.fluid.UnstableFluidFluid;
import net.mcreator.themassivemod.TheMassiveModMod;

public class TheMassiveModModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, TheMassiveModMod.MODID);
	public static final RegistryObject<Fluid> UNSTABLE_FLUID = REGISTRY.register("unstable_fluid", () -> new UnstableFluidFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_UNSTABLE_FLUID = REGISTRY.register("flowing_unstable_fluid",
			() -> new UnstableFluidFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(UNSTABLE_FLUID.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_UNSTABLE_FLUID.get(), renderType -> renderType == RenderType.translucent());
		}
	}
}
