package net.mcreator.themassivemod.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class FixBedrockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double value = 0;
		for (int index0 = 0; index0 < (int) (15); index0++) {
			value = 0;
			world.setBlock(new BlockPos(x + value, y, z), Blocks.AIR.defaultBlockState(), 3);
		}
		for (int index1 = 0; index1 < (int) (15); index1++) {
			value = 0;
			world.setBlock(new BlockPos(x - value, y, z), Blocks.AIR.defaultBlockState(), 3);
		}
		for (int index2 = 0; index2 < (int) (15); index2++) {
			value = 0;
			world.setBlock(new BlockPos(x, y + value, z), Blocks.AIR.defaultBlockState(), 3);
		}
		for (int index3 = 0; index3 < (int) (15); index3++) {
			value = 0;
			world.setBlock(new BlockPos(x, y - value, z), Blocks.AIR.defaultBlockState(), 3);
		}
		for (int index4 = 0; index4 < (int) (15); index4++) {
			value = 0;
			world.setBlock(new BlockPos(x, y, z + value), Blocks.AIR.defaultBlockState(), 3);
		}
		for (int index5 = 0; index5 < (int) (15); index5++) {
			value = 0;
			world.setBlock(new BlockPos(x, y, z - value), Blocks.AIR.defaultBlockState(), 3);
		}
	}
}
